<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://enshrined.co.uk
 * @since      1.0.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/admin/partials
 */

$errors = get_option( WP_SVG_ERROR_OPTION, array() );

?>

<p>
    <?php esc_html_e( 'Here you can see the sanitisation log for the last 10 SVGs uploaded.', 'wpsvg' ); ?>
</p>

<textarea cols="30" rows="30" class="wpsvg-scan-output" readonly><?php
    foreach ( $errors as $error ) {
        printf( "File: %s\nDate Uploaded: %s\n", $error['file'], $error['time'] );
        echo implode("\n", explode('\n', $error['messages'])) . "\n\n";
    }
?></textarea>
