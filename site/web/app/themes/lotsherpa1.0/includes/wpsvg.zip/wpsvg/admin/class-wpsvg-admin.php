<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://enshrined.co.uk
 * @since      1.0.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/admin
 * @author     Daryll Doyle <daryll@enshrined.co.uk>
 */
class Wpsvg_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Holds the values to be used in the fields callbacks
	 */
	private $options;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 *
	 * @param      string $plugin_name The name of this plugin.
	 * @param      string $version The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpsvg_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpsvg_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wpsvg-admin.css', array(),
			$this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpsvg_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpsvg_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wpsvg-admin.js', array( 'jquery' ),
			$this->version, true );

	}

	/**
	 * Add options page
	 *
	 * @since    1.0.0
	 */
	public function add_plugin_page() {
		// This page will be under "Settings"
		add_options_page( 'WP SVG', 'WP SVG', 'manage_options', 'wpsvg-settings', array( $this, 'create_admin_page' ) );
	}

	/**
	 * Options page callback
	 *
	 * @since    1.0.0
	 */
	public function create_admin_page() {
		$this->options = get_option( WP_SVG_USER_OPTION );

		$links = array(
			array(
				'title' => __( 'Settings', 'wpsvg' ),
				'url'   => add_query_arg( array(
					'page' => 'wpsvg-settings',
				), admin_url( 'admin.php' ) ),
			),
			array(
				'title' => __( 'Scan Library', 'wpsvg' ),
				'url'   => add_query_arg( array(
					'page' => 'wpsvg-settings',
					'tab'  => 'scan',
				), admin_url( 'admin.php' ) ),
			),
            array(
                'title' => __( 'Mime Type Fix', 'wpsvg' ),
                'url'   => add_query_arg( array(
                    'page' => 'wpsvg-settings',
                    'tab'  => 'mime-fix',
                ), admin_url( 'admin.php' ) ),
            ),
            array(
                'title' => __( 'Sanitisation Log', 'wpsvg' ),
                'url'   => add_query_arg( array(
                    'page' => 'wpsvg-settings',
                    'tab'  => 'log',
                ), admin_url( 'admin.php' ) ),
            ),
		);

		$tab = isset( $_GET['tab'] ) ? $_GET['tab'] : false;

		/**
		 * Get the current page URL
		 */
		$current_page = add_query_arg( array(
			'page' => 'wpsvg-settings',
			'tab'  => $tab,
		), admin_url( 'admin.php' ) );

		?>
        <div class="wrap">
            <h1><?php esc_html_e( 'WP SVG Settings', 'wpsvg' ); ?></h1>
            <nav class="nav-tab-wrapper woo-nav-tab-wrapper">
				<?php foreach ( $links as $link ): ?>
                    <a href="<?php echo esc_url( $link['url'] ); ?>"
                       class="nav-tab <?php echo $current_page == $link['url'] ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $link['title'] ); ?></a>
				<?php endforeach; ?>
            </nav>

			<?php

			switch ( $tab ) {
			case 'scan':
				include plugin_dir_path( WP_SVG_PLUGIN_FILE ) . '/admin/partials/wpsvg-admin-svg-scan.php';
			break;

            case 'mime-fix':
                include plugin_dir_path( WP_SVG_PLUGIN_FILE ) . '/admin/partials/wpsvg-admin-svg-mime-fix.php';
            break;

            case 'log':
                include plugin_dir_path( WP_SVG_PLUGIN_FILE ) . '/admin/partials/wpsvg-admin-svg-log.php';
            break;

			default:
			?>
                <form method="post" action="options.php">
					<?php
					// This prints out all hidden setting fields
					settings_fields( 'wp_svg_option_group' );
					do_settings_sections( 'wpsvg-settings' );
					submit_button();
					?>
                </form>
			<?php
			}

			?>

        </div>
		<?php
	}

	/**
	 * Register and add settings
	 *
	 * @since    1.0.0
	 */
	public function page_init() {
		register_setting( 'wp_svg_option_group', // Option group
			'wp_svg_users', // Option name
			array( $this, 'sanitize' ) // Sanitize
		);

		add_settings_section( 'licence_section_id', // ID
			__( 'Licence', 'wpsvg' ), // Title
			array( $this, 'print_licence_info' ), // Callback
			'wpsvg-settings' // Page
		);

		add_settings_field( WP_SVG_LICENSE_KEY, // ID
			'', // Title
			'wp_svg_license_page', // Callback
			'wpsvg-settings', // Page
			'licence_section_id' // Section
		);

		add_settings_section( 'setting_section_id', // ID
			__( 'Users', 'wpsvg' ), // Title
			array( $this, 'print_section_info' ), // Callback
			'wpsvg-settings' // Page
		);

		add_settings_field( 'svg_restrict_users', // ID
			__( 'Restrict Users', 'wpsvg' ), // Title
			array( $this, 'print_restrict_users_info' ), // Callback
			'wpsvg-settings', // Page
			'setting_section_id' // Section
		);

		add_settings_field( 'svg_users', // ID
			__( 'Allowed Users', 'wpsvg' ), // Title
			array( $this, 'print_users_info' ), // Callback
			'wpsvg-settings', // Page
			'setting_section_id' // Section
		);
	}

	/**
	 * Sanitize each setting field as needed
	 *
	 * @since    1.0.0
	 *
	 * @param array $input Contains all settings fields as array keys
	 */
	public function sanitize( $input ) {
		$new_input = array(
			'restrict' => 'false',
			'users'    => array(),
		);

		if ( isset( $input['restrict'] ) ) {
			$new_input['restrict'] = $input['restrict'];
		}

		if ( isset( $input['users'] ) ) {
			$new_input['users'] = $input['users'];
		}

		return $new_input;
	}

	/**
	 * Print the Section text
	 *
	 * @since    1.0.0
	 */
	public function print_section_info() {
		esc_html_e( 'Do you want to restrict SVG uploads to certain users and if so, which ones?', 'wpsvg' );
	}

	/**
	 * Print the Section text
	 *
	 * @since    1.0.0
	 */
	public function print_licence_info() {
        esc_html_e( 'Your WP SVG Licence can be managed here', 'wpsvg' );
	}

	/**
	 * Get the settings option array and print one of its values
	 *
	 * @since    1.0.0
	 */
	public function print_users_info() {
		$allowed_users = (array) $this->options['users'];
		$users         = get_users();

		print '<table class="svg-users">';

		foreach ( $users as $user ) {
			print '<tr>';
			printf( '<td><label for="user%s">%s</label></td>', esc_attr($user->ID), esc_html($user->data->user_email) );
			printf( '<td><input type="checkbox" name="wp_svg_users[users][]" value="%s" id="user%s" %s /></td>',
				esc_attr($user->ID), esc_attr($user->ID), checked( in_array( $user->ID, $allowed_users ), true, false ) );
			print '</tr>';
		}

		print '</table>';
	}

	/**
	 * Get the settings option array and print one of its values
	 *
	 * @since    1.0.0
	 */
	public function print_restrict_users_info() {
		$restrict_users = $this->options['restrict'];

		print( '<select name="wp_svg_users[restrict]" >' );
		printf( '<option value="true" %s>%s</option>', ( $restrict_users == 'true' ? 'selected="selected"' : '' ),
			esc_html__( 'Yes', 'wpsvg' ) );
		printf( '<option value="false" %s>%s</option>', ( $restrict_users == 'false' ? 'selected="selected"' : '' ),
			esc_html__( 'No', 'wpsvg' ) );
		print( '</select>' );
	}

	/**
	 * If the featured image is an SVG we wrap it in an SVG class so we can apply our CSS fix.
	 *
	 * @since 1.0.1
	 *
	 * @param string $content Admin post thumbnail HTML markup.
	 * @param int $post_id Post ID.
	 * @param int $thumbnail_id Thumbnail ID.
	 *
	 * @return string
	 */
	public function featured_image_fix( $content, $post_id, $thumbnail_id ) {
		$mime = get_post_mime_type( $thumbnail_id );

		if ( 'image/svg+xml' === $mime ) {
			$content = sprintf( '<span class="svg">%s</span>', $content );
		}

		return $content;
	}

	/**
	 * Skip regenerating SVGs
	 *
	 * @since 1.2.1
	 *
	 * @param int $attachment_id Attachment Id to process.
	 * @param string $file Filepath of the Attached image.
	 *
	 * @return mixed Metadata for attachment.
	 */
	function skip_svg_regeneration( $metadata, $attachment_id ) {
        $mime = get_post_mime_type( $attachment_id );
        if ( 'image/svg+xml' === $mime ) {
            $additional_image_sizes = wp_get_additional_image_sizes();
            $svg_path               = get_attached_file( $attachment_id );
            $upload_dir             = wp_upload_dir();
            // get the path relative to /uploads/ - found no better way:
            $relative_path = str_replace( $upload_dir['basedir'], '', $svg_path );
            $filename      = basename( $svg_path );

            $dimensions = $this->svg_dimensions( $svg_path );

            $metadata = array(
                'width'  => intval( $dimensions['width'] ),
                'height' => intval( $dimensions['height'] ),
                'file'   => $relative_path
            );

            // Might come handy to create the sizes array too - But it's not needed for this workaround! Always links to original svg-file => Hey, it's a vector graphic! ;)
            $sizes = array();
            foreach ( get_intermediate_image_sizes() as $s ) {
                $sizes[ $s ] = array( 'width' => '', 'height' => '', 'crop' => false );

                if ( isset( $additional_image_sizes[ $s ]['width'] ) ) {
                    // For theme-added sizes
                    $sizes[ $s ]['width'] = intval( $additional_image_sizes[ $s ]['width'] );
                } else {
                    // For default sizes set in options
                    $sizes[ $s ]['width'] = get_option( "{$s}_size_w" );
                }

                if ( isset( $additional_image_sizes[ $s ]['height'] ) ) {
                    // For theme-added sizes
                    $sizes[ $s ]['height'] = intval( $additional_image_sizes[ $s ]['height'] );
                } else {
                    // For default sizes set in options
                    $sizes[ $s ]['height'] = get_option( "{$s}_size_h" );
                }

                if ( isset( $additional_image_sizes[ $s ]['crop'] ) ) {
                    // For theme-added sizes
                    $sizes[ $s ]['crop'] = intval( $additional_image_sizes[ $s ]['crop'] );
                } else {
                    // For default sizes set in options
                    $sizes[ $s ]['crop'] = get_option( "{$s}_crop" );
                }

                $sizes[ $s ]['file']      = $filename;
                $sizes[ $s ]['mime-type'] = $mime;
            }
            $metadata['sizes'] = $sizes;
        }

		return $metadata;
	}

	/**
	 * Filters the attachment meta data.
	 *
	 * @since 1.2.2
	 *
	 * @param array|bool $data Array of meta data for the given attachment, or false
	 *                            if the object does not exist.
	 * @param int $post_id Attachment ID.
	 */
	function metadata_error_fix( $data, $post_id ) {

		// If it's a WP_Error regenerate metadata and save it
		if ( is_wp_error( $data ) ) {
			$data = wp_generate_attachment_metadata( $post_id, get_attached_file( $post_id ) );
			wp_update_attachment_metadata( $post_id, $data );
		}

		return $data;
	}

	/**
	 * Add an inline SVG button to the WYSIWYG editor.
	 *
	 * @since   1.4.0
	 */
	function add_inline_svg_button() {

		/**
		 * Should the inline SVG button be shown to the user?
		 *
         * @var bool Whether to show the SVG button or not
		 */
		if ( apply_filters( 'wpsvg_show_inline_editor_button', true ) ) {
			printf( '<button type="button" id="wpsvg-insert-inline" class="button">%s</button>',
				esc_html__( 'Add inline SVG', 'wpsvg' ) );
		}
	}

	/**
	 * Scan the media library for already uploaded SVGs and sanitise them!
	 *
	 * @since   1.5.0
	 */
	public function scan_media_lib() {

		$svg = get_post( absint( $_POST['svg'] ) );

		$url       = wp_get_attachment_url( $svg->ID );
		$uploads   = wp_upload_dir();
		$file_path = str_replace( $uploads['baseurl'], $uploads['basedir'], $url );
		$sanitiser = new Wpsvg_Sanitiser( $this->plugin_name, $this->version );

		$data = array(
			'svg'     => $svg,
			'success' => $sanitiser->sanitize( $file_path ),
			'path'    => $file_path,
		);

		header( 'Content-Type: application/json' );
		echo json_encode( $data );
		exit();
	}

	/**
     * Get SVG size from the width/height or viewport
     *
	 * @param $svg
	 *
	 * @return array
	 */
	protected function svg_dimensions( $svg ) {
		$svg    = @simplexml_load_file( $svg );
		$width  = 0;
		$height = 0;
		if ( $svg ) {
			$attributes = $svg->attributes();
			if ( isset( $attributes->width, $attributes->height ) ) {
				$width  = floatval( $attributes->width );
				$height = floatval( $attributes->height );
			} elseif ( isset( $attributes->viewBox ) ) {
				$sizes = explode( ' ', $attributes->viewBox );
				if ( isset( $sizes[2], $sizes[3] ) ) {
					$width  = floatval( $sizes[2] );
					$height = floatval( $sizes[3] );
				}
			}
		}

		return array(
            'width' => $width,
            'height' => $height,
            'orientation' => ($width > $height) ? 'landscape' : 'portrait'
        );
	}

    /**
     * Get all items in the media library that are missing mime type.
     *
     * @since 1.8.0
     *
     * @return array|null|object
     */
	protected function get_attachments_without_mime() {
	    global $wpdb;

        $missing_mimes = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE `post_type` = 'attachment' AND `post_mime_type` = ''" );

        return $missing_mimes;
    }

    /**
     * Scan the media library for items without a mime type and attemt to fix it.!
     *
     * @since   1.8.0
     */
    public function scan_media_mimes() {
        $media = get_post( absint( $_POST['item'] ) );

        $url       = wp_get_attachment_url( $media->ID );
        $uploads   = wp_upload_dir();
        $file_path = str_replace( $uploads['baseurl'], $uploads['basedir'], $url );

        $mime = wp_check_filetype( $file_path );

        // We got a valid mime.
        if ( is_array( $mime ) && isset( $mime['type'] ) && false !== $mime['type'] ) {
            wp_update_post( array(
                'ID'             => $media->ID,
                'post_mime_type' => $mime['type'],
            ) );
        }

        $data = array(
            'media'   => $media,
            'success' => $mime['type'],
            'path'    => $file_path,
        );

        header( 'Content-Type: application/json' );
        echo json_encode( $data );
        exit();
    }
}
