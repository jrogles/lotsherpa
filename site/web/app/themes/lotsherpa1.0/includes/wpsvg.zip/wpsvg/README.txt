=== Safe SVG ===
Contributors: enshrined
Donate link: https://wpsvg.com/
Tags: svg, sanitize, upload, sanitise, security, svg upload, image, vector, file, graphic, media, mime
Requires at least: 4.0
Tested up to: 4.9.0
Stable tag: 1.13.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enable SVG uploads and sanitize them to stop XML/SVG vulnerabilities in your WordPress website

== Description ==

Safe SVG is the best way to Allow SVG Uploads in WordPress!

It gives you the ability to allow SVG uploads whilst making sure that they're sanitized to stop SVG/XML vulnerabilities affecting your site.
It also gives you the ability to preview your uploaded SVGs in the media library in all views.

>**[Loving Safe SVG? Try the Pro version for extra features.](https://wpsvg.com/)**

#### Free Features
* **Sanitised SVGs** - Don't open up security holes in your WordPress site by allowing uploads of unsanitised files.
* **View SVGs in the Media Library** - Gone are the days of guessing which SVG is the correct one, we'll enable SVG previews in the WordPress media library.

#### Pro Features
* **SVGO Optimisation** - You'll have the option to run your SVGs through our SVGO server on upload to save you space.
* **Choose Who Can Upload** - Restrict SVG uploads to certain users on your WordPress site or allow anyone to upload.
* **Premium Support** - Pro users get premium support whilst free support is offered in the WordPress forums in our spare time


Initially a proof of concept for [#24251](https://core.trac.wordpress.org/ticket/24251)

SVG Sanitization is done through the following library: [https://github.com/darylldoyle/svg-sanitizer](https://github.com/darylldoyle/svg-sanitizer)

== Installation ==

Install through the WordPress directory or download, unzip and upload the files to your `/wp-content/plugins/` directory

== Changelog ==

= 1.9.0 =
* General bugfixes
* Added new feature so you can see last 10 upload logs for SVG files.

= 1.8.0 =
* Added the ability to scan the media library for attachments with missing mimes and try to fix them automatically.

= 1.7.0 =
* Fixed some small bugs with displaying images using differeing WordPress functions.

= 1.6.0 =
* Updated underlying lib and added new filters for filtering allowed tags and attributes

= 1.5.0 =
* Scan SVGs already in the media library

= 1.4.2 =
* Removes default size of 2000x2000px and actually uses the chosen size for the image inserted

= 1.4.1 =
* Fix for page builders inline SVG button not working.

= 1.4.0 =
* Add SVGs inline to pages or posts.

= 1.3.2 =
* Fixes issue if connection to SVGO server times out

= 1.3.1 =
* Allow embedding images in SVGs


= 1.3.0 =
* Fairly big new feature, we not allow `<use>` elements as long as they don't reference external files


= 1.2.2 =
* 1.2.1 introduced an issue that can freeze the media library. This fixes that issue. Sorry!

= 1.2.1 =
* Tested with 4.9.0
* Fixed an issue with SVGs when regenerating media

= 1.2.0 =
* Library update
* Role, aria- and data- attributes are now whitelisted to improve accessibility

= 1.1.0 =
* Library update
* Fixes for images being inserted at strange sizes

= 1.0.1 =
* SVGs now display as featured images in the admin area

= 1.0.0 =
* Initial Release