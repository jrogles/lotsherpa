<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://enshrined.co.uk
 * @since             1.0.0
 * @package           Wpsvg
 *
 * @wordpress-plugin
 * Plugin Name:       WP SVG
 * Plugin URI:        https://wpsvg.com/
 * Description:       The best way to allow SVG uploads in WordPress
 * Version:           1.13.1
 * Author:            Daryll Doyle
 * Author URI:        https://enshrined.co.uk
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wpsvg
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wpsvg-activator.php
 */
function activate_wpsvg() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wpsvg-activator.php';
	Wpsvg_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wpsvg-deactivator.php
 */
function deactivate_wpsvg() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wpsvg-deactivator.php';
	Wpsvg_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wpsvg' );
register_deactivation_hook( __FILE__, 'deactivate_wpsvg' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wpsvg.php';

/**
 * Add licencing
 */
require plugin_dir_path( __FILE__ ) . 'edd/edd.php';

define( 'WP_SVG_VERSION', '1.13.1' );
define( 'WP_SVG_PLUGIN_FILE', __FILE__ );
define( 'WP_SVG_SVGO_LOCATION', 'https://svgo.wpsvg.com' );
define( 'WP_SVG_USER_OPTION', 'wp_svg_users' );
define( 'WP_SVG_ERROR_OPTION', 'wp_svg_errors' );

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wpsvg() {

	$plugin = new Wpsvg();
	$plugin->run();

}

run_wpsvg();
