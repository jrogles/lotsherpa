<?php

/**
 * Holds functions used to fix quirks in the way WP handles SVGs.
 *
 * @link       https://enshrined.co.uk
 * @since      1.1.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 */

/**
 * Holds functions used to fix quirks in the way WP handles SVGs.
 *
 * @since      1.1.0
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 * @author     Daryll Doyle <daryll@enshrined.co.uk>
 */
class Wpsvg_Fixes {

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $plugin_name The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $version The current version of the plugin.
	 */
	protected $version;


	/**
	 * Set up the class
	 *
	 * @since    1.0.0
	 */
	function __construct( $name, $version ) {

		$this->plugin_name = $name;
		$this->version     = $version;
	}

	/**
	 * Filters the attachment data prepared for JavaScript to add the sizes array to the response
	 *
	 * @since    1.0.0
	 *
	 * @param array $response Array of prepared attachment data.
	 * @param int|object $attachment Attachment ID or object.
	 * @param array $meta Array of attachment meta data.
	 *
	 * @return array
	 */
	public function fix_admin_preview( $response, $attachment, $meta ) {

		if ( $response['mime'] == 'image/svg+xml' ) {

            $dimensions = $this->svg_dimensions( get_attached_file( $attachment->ID ) );
            if ( is_array( $dimensions ) ) {
                $response = array_merge( $response, $dimensions );
            }

			$possible_sizes = apply_filters( 'image_size_names_choose', array(
				'full'      => __( 'Full Size' ),
				'thumbnail' => __( 'Thumbnail' ),
				'medium'    => __( 'Medium' ),
				'large'     => __( 'Large' ),
			) );

			$sizes = array();

			foreach ( $possible_sizes as $size => $label ) {
				$default_height = 2000;
				$default_width  = 2000;

                if ( 'full' === $size && $dimensions ) {
                    $default_height = $dimensions['height'];
                    $default_width  = $dimensions['width'];
                }

				$sizes[ $size ] = array(
					'height'      => get_option( "{$size}_size_w", $default_height ),
					'width'       => get_option( "{$size}_size_h", $default_width ),
					'url'         => $response['url'],
					'orientation' => 'portrait',
				);
			}

			$response['sizes'] = $sizes;

			$response['icon'] = $response['url'];
		}

		return $response;
	}

	/**
	 * Filters the image src result.
	 * Here we're gonna spoof the image size and set it to 100 width and height
	 *
	 * @since    1.0.0
	 *
	 * @param array|false $image Either array with src, width & height, icon src, or false.
	 * @param int $attachment_id Image attachment ID.
	 * @param string|array $size Size of image. Image size or array of width and height values
	 *                                    (in that order). Default 'thumbnail'.
	 * @param bool $icon Whether the image should be treated as an icon. Default false.
	 *
	 * @return array
	 */
	public function one_pixel_fix( $image, $attachment_id, $size, $icon ) {
		if ( get_post_mime_type( $attachment_id ) == 'image/svg+xml' ) {
			$image['1'] = false;
			$image['2'] = false;
		}

		return $image;
	}

	/**
	 * Override the default height and width string on an SVG
	 *
	 * @since   1.1.0
	 *
	 * @param string $html HTML content for the image.
	 * @param int $id Attachment ID.
	 * @param string $alt Alternate text.
	 * @param string $title Attachment title.
	 * @param string $align Part of the class name for aligning the image.
	 * @param string|array $size Size of image. Image size or array of width and height values (in that order).
	 *                            Default 'medium'.
	 *
	 * @return mixed
	 */
	function get_image_tag_override( $html, $id, $alt, $title, $align, $size ) {
		$mime = get_post_mime_type( $id );
		if ( 'image/svg+xml' === $mime ) {
			if ( is_array( $size ) ) {
				$width  = $size[0];
				$height = $size[1];
			} elseif ( 'full' == $size && $dimensions = $this->svg_dimensions( get_attached_file( $id ) ) ) {
				$width  = $dimensions['width'];
				$height = $dimensions['height'];
			} else {
				$width  = get_option( "{$size}_size_w", false );
				$height = get_option( "{$size}_size_h", false );
			}

			if ( $height && $width ) {
				$html = str_replace( 'width="1" ', sprintf( 'width="%s" ', $width ), $html );
				$html = str_replace( 'height="1" ', sprintf( 'height="%s" ', $height ), $html );
			} else {
				$html = str_replace( 'width="1" ', '', $html );
				$html = str_replace( 'height="1" ', '', $html );
			}
		}

		return $html;
	}

	/**
	 * Get SVG size from the width/height or viewport.
	 *
	 * @param $svg
	 *
	 * @return array|bool
	 */
	protected function svg_dimensions( $svg ) {
		$svg    = @simplexml_load_file( $svg );
		$width  = 0;
		$height = 0;
		if ( $svg ) {
			$attributes = $svg->attributes();
			if ( isset( $attributes->width, $attributes->height ) ) {
				$width  = floatval( $attributes->width );
				$height = floatval( $attributes->height );
			} elseif ( isset( $attributes->viewBox ) ) {
				$sizes = explode( ' ', $attributes->viewBox );
				if ( isset( $sizes[2], $sizes[3] ) ) {
					$width  = floatval( $sizes[2] );
					$height = floatval( $sizes[3] );
				}
			} else {
				return false;
			}
		}

        return array(
            'width' => $width,
            'height' => $height,
            'orientation' => ($width >= $height) ? 'portrait' : 'landscape'
        );
	}

	/**
	 * Fix the output of images using wp_get_attachment_image
	 *
	 * @param array $attr Attributes for the image markup.
	 * @param WP_Post $attachment Image attachment post.
	 * @param string|array $size Requested size. Image size or array of width and height values
	 *                                 (in that order). Default 'thumbnail'.
	 */
	public function fix_direct_image_output( $attr, $attachment, $size ) {

        // If we're not getting a WP_Post object, bail early.
        // @see https://wordpress.org/support/topic/notice-trying-to-get-property-id/
        if ( ! $attachment instanceof WP_Post ) {
            return $attr;
        }

	    $mime = get_post_mime_type( $attachment->ID );
		if ( 'image/svg+xml' === $mime ) {
			$default_height = 100;
			$default_width  = 100;

			$dimensions = $this->svg_dimensions( get_attached_file( $attachment->ID ) );

			if ( $dimensions ) {
				$default_height = $dimensions['height'];
				$default_width  = $dimensions['width'];
			}

			$attr['height'] = $default_height;
			$attr['width']  = $default_width;
		}

		return $attr;
	}

}
