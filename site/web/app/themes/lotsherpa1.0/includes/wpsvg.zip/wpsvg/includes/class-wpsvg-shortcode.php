<?php

/**
 * Handle shortcodes.
 *
 * @link       https://enshrined.co.uk
 * @since      1.4.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 */

/**
 * Handle shortcodes.
 *
 * This class defines all code used to parse shortcodes.
 *
 * @since      1.4.0
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 * @author     Daryll Doyle <daryll@enshrined.co.uk>
 */
class Wpsvg_Shortcode {

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.4.0
	 * @access   protected
	 * @var      string $plugin_name The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.4.0
	 * @access   protected
	 * @var      string $version The current version of the plugin.
	 */
	protected $version;


	/**
	 * Set up the class
	 *
	 * @since    1.4.0
	 */
	function __construct( $name, $version ) {

		$this->plugin_name = $name;
		$this->version     = $version;
	}

	/**
	 * Handle the inline SVG shortcode
	 *
	 * @since   1.4.0
	 *
	 * @param   array $atts The attributes passed to the shortcode.
	 *
	 * @return string
	 */
	public function inline_svg( $atts ) {
		$atts = shortcode_atts( array(
			'id' => false,
		), $atts, 'wpsvg_inline' );

		// If image id is false, nothing was passed so return a blank string
		if ( ! $atts['id'] ) {
			return '';
		}

		// If image is not an SVG return empty string
		if ( 'image/svg+xml' !== get_post_mime_type( $atts['id'] ) ) {
			return '';
		}

		// If we couldn't get the contents of the file, empty string again
		if ( ! $contents = file_get_contents( get_attached_file( $atts['id'] ) ) ) {
			return '';
		}

		// Decode the file if it's an SVGZ as that won't display
		if ( $is_zipped = $this->is_gzipped( $contents ) ) {
			$contents = gzdecode( $contents );

			// If decoding fails, return an empty srting
			if ( $contents === false ) {
				return '';
			}
		}

		/**
		 * The wrapper class name.
		 *
		 * Allows a user to adjust the inline svg wrapper class name.
		 *
		 * @since 1.4.0
		 *
		 * @param string The class name.
		 */
		$class_name = apply_filters('wpsvg_inline_svg_class', 'wpsvg-inline' );

		/**
		 * The wrapper markup.
		 *
		 * Allows a user to adjust the inline svg wrapper markup.
		 *
		 * @since 1.4.0
		 *
		 * @param string                The current wrapper markup.
		 * @param string $contents      The SVG contents.
		 * @param string $class_name    The wrapper class name.
		 * @param int    $attachment_id The ID of the attachment.
		 */
		return apply_filters('wpsvg_inline_svg_markup', sprintf( '<div class="%s %s">%s</div>', $class_name, sprintf('%s--%s', $class_name, $atts['id']), $contents ), $contents, $class_name, $atts['id'] );
	}

	/**
	 * Check if the contents are gzipped
	 *
	 * @see      http://www.gzip.org/zlib/rfc-gzip.html#member-format
	 *
	 * @since    1.4.0
	 *
	 * @param $contents
	 *
	 * @return bool
	 */
	protected function is_gzipped( $contents ) {
		if ( function_exists( 'mb_strpos' ) ) {
			return 0 === mb_strpos( $contents, "\x1f" . "\x8b" . "\x08" );
		} else {
			return 0 === strpos( $contents, "\x1f" . "\x8b" . "\x08" );
		}
	}
}
