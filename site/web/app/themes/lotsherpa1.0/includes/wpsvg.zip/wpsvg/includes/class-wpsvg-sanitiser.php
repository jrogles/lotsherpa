<?php

/**
 * Handle all sanitation tasks.
 *
 * @link       https://enshrined.co.uk
 * @since      1.0.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 */

/**
 * Handle all sanitation tasks.
 *
 * This class defines all code necessary to sanitise a file.
 *
 * @since      1.0.0
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 * @author     Daryll Doyle <daryll@enshrined.co.uk>
 */
class Wpsvg_Sanitiser {

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $plugin_name The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $version The current version of the plugin.
	 */
	protected $version;

	/**
	 * The sanitizer
	 *
	 * @since    1.0.0
	 *
	 * @var \enshrined\svgSanitize\Sanitizer
	 */
	protected $sanitizer;

	/**
	 * Our plugin options
	 *
	 * @since    1.0.0
	 *
	 * @var array
	 */
	protected $options;

	/**
	 * Set up the class
	 *
	 * @since    1.0.0
	 */
	function __construct( $name, $version ) {

		$this->plugin_name = $name;
		$this->version     = $version;

		$this->sanitizer = new enshrined\svgSanitize\Sanitizer();
		$this->sanitizer->minify( true );

		$this->options = get_option( WP_SVG_USER_OPTION );
	}

	/**
	 * Allow SVG Uploads
	 *
	 * @since    1.0.0
	 *
	 * @param $mimes
	 *
	 * @return mixed
	 */
	public function allow_svg( $mimes ) {
		$mimes['svg']  = 'image/svg+xml';
		$mimes['svgz'] = 'image/svg+xml';

		return $mimes;
	}

	/**
	 * Fixes the issue in WordPress 4.7.1 being unable to correctly identify SVGs
	 *
	 * @thanks @lewiscowles
	 *
	 * @since    1.0.0
	 *
	 * @param null $data
	 * @param null $file
	 * @param null $filename
	 * @param null $mimes
	 *
	 * @return null
	 */
	public function fix_mime_type_svg( $data = null, $file = null, $filename = null, $mimes = null ) {
		$ext = isset( $data['ext'] ) ? $data['ext'] : '';
		if ( strlen( $ext ) < 1 ) {
			$ext = strtolower( end( explode( '.', $filename ) ) );
		}
		if ( $ext === 'svg' ) {
			$data['type'] = 'image/svg+xml';
			$data['ext']  = 'svg';
		} elseif ( $ext === 'svgz' ) {
			$data['type'] = 'image/svg+xml';
			$data['ext']  = 'svgz';
		}

		return $data;
	}

	/**
	 * Check if the file is an SVG, if so handle appropriately
	 *
	 * @since    1.0.0
	 *
	 * @param $file
	 *
	 * @return mixed
	 */
	public function check_for_svg( $file ) {

		if ( $file['type'] === 'image/svg+xml' ) {

			if ( ! $this->can_user_upload() ) {
				$file['error'] = __( "Sorry, you don't have permission to upload SVG files", 'wpsvg' );
			} else {
			    $sanitise_response = $this->sanitize( $file['tmp_name'], $file['name'] );

				if ( ! $sanitise_response ) {
					$file['error'] = __( "Sorry, this file couldn't be sanitized so for security reasons wasn't uploaded", 'wpsvg' );
				}
			}
		}

		return $file;
	}

	/**
	 * Can a user upload SVGs
	 *
	 * @since    1.0.0
	 *
	 * @return bool
	 */
	protected function can_user_upload() {
		$user_id       = get_current_user_id();
		$allowed_users = (array) $this->options['users'];

		if ( $this->options['restrict'] == 'true' ) {
			return in_array( $user_id, $allowed_users );
		}

		return true;
	}

	/**
	 * Sanitize the SVG
	 *
	 * @since    1.0.0
	 *
     * @param $file
     * @param $file_name
	 *
	 * @return bool|int
	 */
	public function sanitize( $file, $file_name = 'Unknown' ) {
		$dirty = file_get_contents( $file );

		// Is the SVG gzipped? If so we try and decode the string
		if ( $is_zipped = $this->is_gzipped( $dirty ) ) {
			$dirty = gzdecode( $dirty );

			// If decoding fails, bail as we're not secure
			if ( $dirty === false ) {
                $this->add_sanitisation_log( $file_name,
                    __( 'SVGZ file couldn\'t be decoded for sanitisation', 'wpsvg' ) );
				return false;
			}
		}

		/**
		 * Load extra filters to allow devs to access the safe tags and attrs by themselves.
		 */
		$this->sanitizer->setAllowedTags(new Wpsvg_Tags());
		$this->sanitizer->setAllowedAttrs(new Wpsvg_Attributes());

		$clean = $this->sanitizer->sanitize( $dirty );

		if ( $clean === false ) {
            $this->add_sanitisation_log( $file_name,
                __( 'SVG couldn\'t be sanitised due to an error in the file.', 'wpsvg' ) );
			return false;
		}

		/**
		 * Lets do our SVGO stuff
		 *
		 * @since    1.0.0
		 */
		if ( get_option( WP_SVG_LICENSE_STATUS ) === 'valid' ) {

			$response = wp_remote_post( WP_SVG_SVGO_LOCATION, array(
				'body' => array(
					'licence' => trim( get_option( WP_SVG_LICENSE_KEY ) ),
					'home'    => home_url(),
					'svg'     => $clean,
				),
			) );

			if ( ! is_wp_error( $response ) ) {
				$response = json_decode( $response['body'] );

				// If we get a good response, use the optimised version
				if ( $response->success === true && ! empty( $response->svg ) ) {
					$clean = $response->svg;
				}
			}
		}

		// If we were gzipped, we need to re-zip
		if ( $is_zipped ) {
			$clean = gzencode( $clean );
		}

		file_put_contents( $file, $clean );

        $xml_issues = $this->sanitizer->getXmlIssues();
        if ( count( $xml_issues ) > 0 ) {
            $message = __( 'The following elements/attributes were removed during sanitisation:' . "\n", 'wpsvg' );

            foreach ( $xml_issues as $issue ) {
                $message .= sprintf( '%s on line %s\n', $issue['message'], $issue['line'] );
            }

            $this->add_sanitisation_log( $file_name, $message );
        } else {
            $this->add_sanitisation_log( $file_name, __( 'SVG was OK.', 'wpsvg' ) );
        }

		return true;
	}

    /**
     * Add a sanisation Log
     *
     * @param $file_name
     * @param $message
     */
    protected function add_sanitisation_log( $file_name, $message ) {
        $errors = get_option( WP_SVG_ERROR_OPTION, array() );

        array_unshift( $errors, array(
            'time'     => date( 'Y-m-d H:i:s' ),
            'file'     => $file_name,
            'messages' => $message,
        ) );

        // Make sure we only have 10 messages
        if ( count( $errors ) > 10 ) {
            array_pop( $errors );
        }

        update_option( WP_SVG_ERROR_OPTION, $errors, false );
    }

	/**
	 * Check if the contents are gzipped
	 *
	 * @see      http://www.gzip.org/zlib/rfc-gzip.html#member-format
	 *
	 * @since    1.0.0
	 *
	 * @param $contents
	 *
	 * @return bool
	 */
	protected function is_gzipped( $contents ) {
		if ( function_exists( 'mb_strpos' ) ) {
			return 0 === mb_strpos( $contents, "\x1f" . "\x8b" . "\x08" );
		} else {
			return 0 === strpos( $contents, "\x1f" . "\x8b" . "\x08" );
		}
	}

}
