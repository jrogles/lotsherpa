/**
 * BLOCK: wpsvg-inline
 *
 * Registering a basic block with Gutenberg.
 * Simple block, renders and saves the same content without any interactivity.
 */

//  Import CSS.
import './style.scss';
import './editor.scss';

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { MediaUpload } = wp.editor;
const { Button } = wp.components;

/**
 * Block icon
 */
const iconEl = () => {
	return (
		<svg xmlns="http://www.w3.org/2000/svg" width="24" height="20">
			<g fill="#F49819">
				<path d="M15.808 13.365l-3.335-3.177a.68.68 0 0 0-.94 0l-3.335 3.177a.604.604 0 0 0 0 .894.672.672 0 0 0 .47.188.658.658 0 0 0 .469-.188l2.199-2.094v7.2c0 .353.296.635.667.635.37 0 .667-.282.667-.635v-7.2l2.2 2.094a.672.672 0 0 0 .469.188.658.658 0 0 0 .47-.188.618.618 0 0 0 0-.894z"/>
				<path d="M19.107 6.327C18.795 2.783 15.727 0 11.996 0 8.064 0 4.861 3.11 4.861 6.926c0 .319.024.63.072.948-.08 0-.152-.008-.232-.008C2.106 7.866 0 9.911 0 12.43c0 2.519 2.106 4.563 4.7 4.563h4.053c.36 0 .648-.28.648-.63s-.288-.629-.648-.629H4.7c-1.874 0-3.404-1.485-3.404-3.304 0-1.819 1.53-3.303 3.404-3.303.288 0 .592.039.889.116.224.063.464 0 .632-.163a.608.608 0 0 0 .16-.614 5.436 5.436 0 0 1-.224-1.547c0-3.125 2.619-5.667 5.838-5.667 3.22 0 5.838 2.542 5.838 5.667 0 .35.288.63.648.63 2.323 0 4.22 1.834 4.22 4.096s-1.89 4.097-4.22 4.097H15.24c-.36 0-.648.28-.648.63s.288.629.648.629h3.243C21.526 17 24 14.598 24 11.644c0-2.744-2.138-5.021-4.893-5.317z"/>
			</g>
		</svg>
	)
}

/**
 * Register: aa Gutenberg Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @link https://wordpress.org/gutenberg/handbook/block-api/
 * @param  {string}   name     Block name.
 * @param  {Object}   settings Block settings.
 * @return {?WPBlock}          The block, if it has been successfully
 *                             registered; otherwise `undefined`.
 */
registerBlockType( 'wpsvg/block-wpsvg-inline', {
	// Block name. Block names must be string that contains a namespace prefix. Example: my-plugin/my-custom-block.
	title: __( 'Inline SVG' ), // Block title.
	icon: iconEl,
	category: 'common', // Block category — Group blocks together based on common traits E.g. common, formatting, layout widgets, embed.
	keywords: [
		__( 'Inline SVG' ),
		__( 'SVG' ),
		__( 'Image' ),
	],

	attributes: {
		image_id: {
			type: 'integer',
		},
		image_url: {
			type: 'string',
		},
		className: {
			type: 'string',
		}
	},

	/**
	 * The edit function describes the structure of your block in the context of the editor.
	 * This represents what the editor will render when the block is used.
	 *
	 * The "edit" property must be a valid function.
	 *
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: function( props ) {
		const getImageButton = (openEvent) => {
			if(props.attributes.image_url) {
				return (
					<img
						src={ props.attributes.image_url }
						onClick={ openEvent }
						className="image"
					/>
				);
			}
			else {
				return (
					<div className="button-container">
						<Button
							onClick={ openEvent }
							className="button button-large"
						>
							{__( 'Pick an SVG' )}
						</Button>
					</div>
				);
			}
		};
		// Creates a <p class='wp-block-cgb-block-wpsvg-inline'></p>.
		return (
			<div className={ props.className }>
				<MediaUpload
					onSelect={ media => {
						props.setAttributes({
							image_id: media.id,
							image_url: media.url
						});
					} }
					type="image"
					allowedTypes={[
						"image/svg+xml"
					]}
					value={ props.attributes.image_id }
					render={ ({ open }) => getImageButton(open) }
				/>
			</div>
		);
	},

	/**
	 * The save function defines the way in which the different attributes should be combined
	 * into the final markup, which is then serialized by Gutenberg into post_content.
	 *
	 * The "save" property must be specified and must be a valid function.
	 *
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: function( props ) {
		return null // See PHP side. This block is rendered in PHP.
	},

} );