<?php

// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'WP_SVG_STORE_URL', 'https://wpsvg.com/' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

// the name of your product. This should match the download name in EDD exactly
define( 'WP_SVG_ITEM_NAME', 'WP SVG Pro' ); // you should use your own CONSTANT name, and be sure to replace it throughout this file

// the name of the settings page for the license input to be displayed
define( 'WP_SVG_LICENSE_PAGE', 'wpsvg-settings' );

define( 'WP_SVG_LICENSE_KEY', 'wp_svg_license_key' );
define( 'WP_SVG_LICENSE_STATUS', 'wp_svg_license_status' );
define( 'WP_SVG_LICENSE_DATA', 'wp_svg_license_data' );

if ( ! class_exists( 'SVG_EDD_SL_Plugin_Updater' ) ) {
	// load our custom updater
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

function wp_svg_plugin_updater() {

	// retrieve our license key from the DB
	$license_key = trim( get_option( WP_SVG_LICENSE_KEY ) );

	// setup the updater
	$edd_updater = new SVG_EDD_SL_Plugin_Updater( WP_SVG_STORE_URL, WP_SVG_PLUGIN_FILE, array(
			'version'   => WP_SVG_VERSION,                // current version number
			'license'   => $license_key,        // license key (used get_option above to retrieve from DB)
			'item_name' => WP_SVG_ITEM_NAME,    // name of this plugin
			'author'    => 'Daryll Doyle',  // author of this plugin
			'beta'      => false
		)
	);
}

add_action( 'admin_init', 'wp_svg_plugin_updater', 0 );

//function wp_svg_license_menu() {
//	add_options_page( 'WP SVG License', 'WP SVG License', 'manage_options', WP_SVG_LICENSE_PAGE, 'wp_svg_license_page' );
//}
//add_action('admin_menu', 'wp_svg_license_menu');

function wp_svg_license_page() {
	$license = get_option( WP_SVG_LICENSE_KEY );
	$status  = get_option( WP_SVG_LICENSE_STATUS );
	?>
    <table class="form-table wpsvg-table-fix">
        <tbody>
        <tr valign="top">
            <th scope="row" valign="top">
				<?php _e( 'License Key' ); ?>
            </th>
            <td>
                <input id="<?= WP_SVG_LICENSE_KEY ?>" name="<?= WP_SVG_LICENSE_KEY ?>" type="text" class="regular-text"
                       value="<?php esc_attr_e( $license ); ?>"/>
                <label class="description"
                       for="<?= WP_SVG_LICENSE_KEY ?>"><?php _e( 'Enter your license key' ); ?></label>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row" valign="top">
				<?php _e( 'Activate License' ); ?>
            </th>
            <td>
				<?php if ( $status !== false && $status == 'valid' ) { ?>
                    <span style="color:green;"><?php _e( 'active' ); ?></span>
					<?php wp_nonce_field( 'wp_svg_nonce', 'wp_svg_nonce' ); ?>
                    <input type="submit" class="button-secondary" name="wp_svg_license_deactivate"
                           value="<?php _e( 'Deactivate License' ); ?>"/>
				<?php } else {
					wp_nonce_field( 'wp_svg_nonce', 'wp_svg_nonce' ); ?>
                    <input type="submit" class="button button-primary" name="wp_svg_license_activate"
                           value="<?php _e( 'Activate License' ); ?>"/>
				<?php } ?>
            </td>
        </tr>
        </tbody>
    </table>
	<?php
}

function wp_svg_sanitize_license( $new ) {
	$old = get_option( WP_SVG_LICENSE_KEY );
	if ( $old != $new ) {
		delete_option( WP_SVG_LICENSE_STATUS ); // new license has been entered, so must reactivate
		update_option( WP_SVG_LICENSE_KEY, $new );
	}

	return $new;
}

function wp_svg_check_license() {
	if ( 'valid' != get_option( WP_SVG_LICENSE_STATUS ) ) {
		if ( ( ! isset( $_GET['page'] ) or WP_SVG_LICENSE_PAGE != $_GET['page'] ) ) {
			add_action( 'admin_notices', 'wp_svg_activate_notice' );
		}
	}
}

add_action( 'admin_init', 'wp_svg_check_license' );

function wp_svg_activate_notice() {
	echo '<div class="error"><p>' .
	     sprintf( __( 'WP SVG license needs to be activated.  %sActivate Now%s', 'wp_svg' ), '<a href="' . admin_url( 'options-general.php?page=' . WP_SVG_LICENSE_PAGE ) . '">', '</a>' ) .
	     '</p></div>';
}

/************************************
 * this illustrates how to activate
 * a license key
 *************************************/

function wp_svg_activate_license() {

	// listen for our activate button to be clicked
	if ( isset( $_POST['wp_svg_license_activate'] ) ) {

		// run a quick security check
		if ( ! check_admin_referer( 'wp_svg_nonce', 'wp_svg_nonce' ) ) {
			return;
		} // get out if we didn't click the Activate button

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST[ WP_SVG_LICENSE_KEY ] ) ) {
			wp_svg_sanitize_license( $_POST[ WP_SVG_LICENSE_KEY ] );
		}

		// retrieve the license from the database
		$license = trim( get_option( WP_SVG_LICENSE_KEY ) );

		// data to send in our API request
		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license,
			'item_name'  => urlencode( WP_SVG_ITEM_NAME ), // the name of our product in EDD
			'url'        => home_url()
		);

		// Call the custom API.
		$response = wp_remote_post( WP_SVG_STORE_URL, array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params
		) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.' );
			}

		} else {

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			if ( false === $license_data->success ) {

				switch ( $license_data->error ) {

					case 'expired' :

						$message = sprintf(
							__( 'Your license key expired on %s.' ),
							date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
						);
						break;

					case 'revoked' :

						$message = __( 'Your license key has been disabled.' );
						break;

					case 'missing' :

						$message = __( 'Invalid license.' );
						break;

					case 'invalid' :
					case 'site_inactive' :

						$message = __( 'Your license is not active for this URL.' );
						break;

					case 'item_name_mismatch' :

						$message = sprintf( __( 'This appears to be an invalid license key for %s.' ), WP_SVG_ITEM_NAME );
						break;

					case 'no_activations_left':

						$message = __( 'Your license key has reached its activation limit.' );
						break;

					default :

						$message = __( 'An error occurred, please try again.' );
						break;
				}

			}

		}

		// Check if anything passed on a message constituting a failure
		if ( ! empty( $message ) ) {
			$base_url = admin_url( 'options-general.php?page=' . WP_SVG_LICENSE_PAGE );
			$redirect = add_query_arg( array(
				'wp_svg_sl_activation' => 'false',
				'message'              => urlencode( $message )
			), $base_url );

			wp_redirect( $redirect );
			exit();
		}

		// $license_data->license will be either "valid" or "invalid"

		update_option( WP_SVG_LICENSE_STATUS, $license_data->license );
		update_option( WP_SVG_LICENSE_DATA, $license_data );

		wp_redirect( admin_url( 'options-general.php?page=' . WP_SVG_LICENSE_PAGE ) );
		exit();
	}
}

add_action( 'admin_init', 'wp_svg_activate_license' );


function wp_svg_deactivate_license() {

	// listen for our activate button to be clicked
	if ( isset( $_POST['wp_svg_license_deactivate'] ) ) {

		// run a quick security check
		if ( ! check_admin_referer( 'wp_svg_nonce', 'wp_svg_nonce' ) ) {
			return;
		} // get out if we didn't click the Activate button

		// retrieve the license from the database
		$license = trim( get_option( WP_SVG_LICENSE_KEY ) );


		// data to send in our API request
		$api_params = array(
			'edd_action' => 'deactivate_license',
			'license'    => $license,
			'item_name'  => urlencode( WP_SVG_ITEM_NAME ), // the name of our product in EDD
			'url'        => home_url()
		);

		// Call the custom API.
		$response = wp_remote_post( WP_SVG_STORE_URL, array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params
		) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.' );
			}

			$base_url = admin_url( 'options-general.php?page=' . WP_SVG_LICENSE_PAGE );
			$redirect = add_query_arg( array(
				'wp_svg_sl_activation' => 'false',
				'message'              => urlencode( $message )
			), $base_url );

			wp_redirect( $redirect );
			exit();
		}

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if ( $license_data->license == 'deactivated' ) {
			delete_option( WP_SVG_LICENSE_STATUS );
		}

		wp_redirect( admin_url( 'options-general.php?page=' . WP_SVG_LICENSE_PAGE ) );
		exit();
	}
}

add_action( 'admin_init', 'wp_svg_deactivate_license' );

function wp_svg_check_license_still_valid() {

	global $wp_version;

	$check_option_key = 'wp_svg_check_option_key';

	if ( get_option( $check_option_key ) and get_option( $check_option_key ) > current_time( 'timestamp' ) ) {
		return;
	}

	$license = trim( get_option( WP_SVG_LICENSE_KEY ) );

	$api_params = array(
		'edd_action' => 'check_license',
		'license'    => $license,
		'item_name'  => urlencode( WP_SVG_ITEM_NAME ),
		'url'        => home_url()
	);

	// Call the custom API.
	$response = wp_remote_post( WP_SVG_STORE_URL, array(
		'timeout'   => 15,
		'sslverify' => false,
		'body'      => $api_params
	) );

	if ( is_wp_error( $response ) ) {
		update_option( $check_option_key, current_time( 'timestamp' ) + ( 60 * 60 * 2 ) );

		return;
	}

	$license_data = json_decode( wp_remote_retrieve_body( $response ) );

	update_option( WP_SVG_LICENSE_STATUS, $license_data->license );
	update_option( WP_SVG_LICENSE_DATA, $license_data );

	update_option( $check_option_key, current_time( 'timestamp' ) + ( 60 * 60 * 24 ) );
}

add_action( 'admin_init', 'wp_svg_check_license_still_valid' );

function wp_svg_get_license_data( $key ) {
	$license_data = get_option( WP_SVG_LICENSE_DATA );
	if ( is_object( $license_data ) and isset( $license_data->$key ) ) {
		return $license_data->$key;
	}

	return false;
}

/**
 * This is a means of catching errors from the activation method above and displaying it to the customer
 */
function wp_svg_admin_notices() {
	if ( isset( $_GET['wp_svg_sl_activation'] ) && ! empty( $_GET['message'] ) ) {

		switch ( $_GET['wp_svg_sl_activation'] ) {

			case 'false':
				$message = urldecode( $_GET['message'] );
				?>
                <div class="error">
                    <p><?php echo $message; ?></p>
                </div>
				<?php
				break;

			case 'true':
			default:
				// Developers can put a custom success message here for when activation is successful if they way.
				break;

		}
	}
}

add_action( 'admin_notices', 'wp_svg_admin_notices' );