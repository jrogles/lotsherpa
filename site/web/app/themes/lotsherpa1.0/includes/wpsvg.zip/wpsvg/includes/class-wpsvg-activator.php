<?php

/**
 * Fired during plugin activation
 *
 * @link       https://enshrined.co.uk
 * @since      1.0.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wpsvg
 * @subpackage Wpsvg/includes
 * @author     Daryll Doyle <daryll@enshrined.co.uk>
 */
class Wpsvg_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		add_option( WP_SVG_USER_OPTION, array(
			'restrict' => 'false',
			'users'    => array(),
		) );
	}

}
