<?php


class Wpsvg_Attributes extends \enshrined\svgSanitize\data\AllowedAttributes {

	/**
	 * Returns an array of attributes
	 *
	 * @return array
	 */
	public static function getAttributes() {

		/**
		 * var  array Attributes that are allowed.
		 */
		return apply_filters( 'wpsvg_allowed_attributes', parent::getAttributes() );
	}
}