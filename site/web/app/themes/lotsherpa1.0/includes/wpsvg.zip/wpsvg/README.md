# wpsvg
WP SVG Plugin
