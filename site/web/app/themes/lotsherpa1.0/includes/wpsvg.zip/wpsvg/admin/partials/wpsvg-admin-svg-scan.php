<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://enshrined.co.uk
 * @since      1.0.0
 *
 * @package    Wpsvg
 * @subpackage Wpsvg/admin/partials
 */

$svg_query = new WP_Query( [
    'post_type'      => 'attachment',
    'post_status'    => 'all',
    'post_mime_type' => 'image/svg+xml',
    'posts_per_page' => - 1,
] );

$svgs = $svg_query->get_posts();
?>
    <script>
		var wpsvg_scan = <?php echo json_encode( $svgs ); ?>;
		var wpsvg_total = <?php echo count( $svgs ); ?>;
		var wpsvg_completed = 0;
    </script>

    <p><?php esc_html_e( 'This will scan all the SVGs in your media library and run them through the sanitiser.',
            'wpsvg' ); ?></p>

<?php if ( get_option( WP_SVG_LICENSE_STATUS ) === 'valid' ): ?>

    <button type="button" class="button button-primary wpsvg-scan-lib js-wpsvg-scan-lib">
        <?php esc_html_e( 'Scan Media Library',
            'wpsvg' ); ?>
    </button>

    <div class="wpsvg-progress-wrap wpsvg-progress" data-progress-percent="0" style="display: none">
        <div class="wpsvg-progress-bar wpsvg-progress"></div>
    </div>

    <textarea cols="30" rows="10" class="wpsvg-scan-output js-wpsvg-scan-output" style="display: none"
              readonly></textarea>

<?php else: ?>
    <p><?php esc_html_e( 'Library scanning is only available to active licence holders', 'wpsvg' ); ?></p>
<?php endif; ?>
