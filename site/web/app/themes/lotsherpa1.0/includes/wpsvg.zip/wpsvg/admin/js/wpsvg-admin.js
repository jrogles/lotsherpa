(
    function( $ ) {
        'use strict';

        $( function() {
            $( 'body.wp-admin' ).on( 'click', '#wpsvg-insert-inline', wpsvg_inline_window );
	        $( 'body.wp-admin' ).on( 'click', '.js-wpsvg-scan-lib', scan_media_lib );
	        $( 'body.wp-admin' ).on( 'click', '.js-wpsvg-scan-mimes', scan_media_mimes );

            moveProgressBar();
        } );

        /**
         * Open the inline SVG window and add the shortcode
         *
         * @returns {boolean}
         */
        function wpsvg_inline_window() {
            if ( this.window === undefined ) {
                this.window = wp.media( {
                    title: 'Insert an SVG',
                    library: { type: 'image/svg+xml' },
                    multiple: false,
                    button: { text: 'Insert SVG' }
                } );

                var self = this; // Needed to retrieve our variable in the anonymous function below
                this.window.on( 'select', function() {
                    var first = self.window.state().get( 'selection' ).first().toJSON();
                    wp.media.editor.insert( '[wpsvg_inline id="' + first.id + '"]' );
                } );
            }

            this.window.open();
            return false;
        }

        /**
         * Scan media library handler
         *
         * @since   1.5.0
         */
        function scan_media_lib() {

            var button = $( '.js-wpsvg-scan-lib' );
            var logbox = $( '.js-wpsvg-scan-output' );
            var progress = $( '.wpsvg-progress-wrap' );

            button.hide();
            logbox.show();
            progress.show();

            logbox.append( 'Scanning ' + wpsvg_total + ' SVGs found in the media library' + "\n\n" );

            wpsvg_scan.forEach( function( svg ) {
                var data = {
                    'action': 'wpsvg_scan_media_lib',
                    'svg': svg.ID,
                };

                // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
                jQuery.post( ajaxurl, data, function( response ) {

                    var status = '(ID: ' + response.svg.ID + ') ' + response.svg.guid;

                    if ( response.success ) {
                        status = '✓ ' + status + ' successfully sanitised';
                    } else {
                        status = '✗ ' + status + ' failed to sanitise';
                    }

                    logbox.append( status + "\n" );

                    wpsvg_completed++;
                    var total = (wpsvg_completed / wpsvg_total) * 100;
                    progress.attr( 'data-progress-percent', total );
                    moveProgressBar();
                } );
            } );
        }

        /**
         * Progress bar handler
         *
         * @since   1.5.0
         */
        function moveProgressBar() {
            if ( $( '.wpsvg-progress-wrap' ).length > 0 ) {
                var getPercent = ($( '.wpsvg-progress-wrap' ).attr( 'data-progress-percent' ) / 100);
                var getProgressWrapWidth = $( '.wpsvg-progress-wrap' ).width();
                var progressTotal = getPercent * getProgressWrapWidth;
                var animationLength = 500;

                // on page load, animate percentage bar to data percentage length
                // .stop() used to prevent animation queueing
                $( '.wpsvg-progress-bar' ).stop().animate( {
                    left: progressTotal
                }, animationLength );
            }
        }


	    /**
	     * Scan media library handler
	     *
	     * @since   1.5.0
	     */
	    function scan_media_mimes() {

		    var button = $( '.js-wpsvg-scan-lib' );
		    var logbox = $( '.js-wpsvg-scan-output' );
		    var progress = $( '.wpsvg-progress-wrap' );

		    button.hide();
		    logbox.show();
		    progress.show();

		    logbox.append( 'Scanning ' + wpsvg_media_total + ' items found in the media library, without a mime type' + "\n\n" );

		    wpsvg_media_scan.forEach( function( media ) {
			    var data = {
				    'action': 'wpsvg_scan_media_mimes',
				    'item': media.ID,
			    };

			    // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
			    jQuery.post( ajaxurl, data, function( response ) {

				    var status = '(ID: ' + response.media.ID + ') ' + response.media.guid;

				    if ( response.success ) {
					    status = '✓ ' + status + ' mime type set to ' + response.success;
				    } else {
					    status = '✗ ' + status + ' failed to determine mime type';
				    }

				    logbox.append( status + "\n" );

				    wpsvg_media_completed++;
				    var total = (wpsvg_media_completed / wpsvg_media_total) * 100;
				    progress.attr( 'data-progress-percent', total );
				    moveProgressBar();
			    } );
		    } );
	    }

    }
)( jQuery );